import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

/** 
 * Servlet that processes a big form.
 */
public class ProcessBigForm extends HttpServlet {
   public void doPost(HttpServletRequest req, HttpServletResponse res)
                    throws ServletException, IOException {
      res.setContentType("text/html");
      PrintWriter out = res.getWriter();

      out.println("<table border=1>");

      // Obtain all the form's parameters from the request object.
      Enumeration paramNames = req.getParameterNames();
	
      while (paramNames.hasMoreElements()) {
        String paramName = (String) paramNames.nextElement();

        // Obtain values for this parameter and check how many there are.
        String[] paramValues = req.getParameterValues(paramName);

        if (paramValues.length == 1) { // a single value
          String paramVal  = req.getParameter(paramName);	
          out.println("<tr><td>" + paramName +"</td><td>" + paramVal + "</td></tr>");
        }
        else {   // If several values print a list in the table. 
          out.println("<tr><td>" + paramName +"</td><td><ul>");
          for (int i = 0; i < paramValues.length; i++)
            out.println("<li>" + paramValues[i] + "</li>");
          out.println("</ul></td></tr>");
        }
      }
      out.println("</table>");
      out.close();
   }
}