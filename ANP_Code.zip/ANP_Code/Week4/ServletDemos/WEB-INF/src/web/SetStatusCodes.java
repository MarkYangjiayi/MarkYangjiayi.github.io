package web;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class SetStatusCodes extends HttpServlet {
  public void doPost(HttpServletRequest req, HttpServletResponse res)
                    throws ServletException, IOException {
  
    // Generate response according to which submit button was pressed.
    if (req.getParameter("non-file") != null)
      res.sendError(res.SC_NOT_FOUND, "The file you requested does not exist!");
    if (req.getParameter("redirect") != null)
      res.sendRedirect(res.encodeURL("http://localhost:9999/"));
    if (req.getParameter("censored") != null)
      res.setStatus(res.SC_FORBIDDEN);
    res.setContentType("text/html");
    PrintWriter out = res.getWriter();
    out.println("<html>");
      // More code here.
    out.println("</html>");
    out.close();
  }
}