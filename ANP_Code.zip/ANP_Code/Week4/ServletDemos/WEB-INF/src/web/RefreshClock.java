package web;

/*****************************************************************/
/* Copyright 2013 Code Strategies                                */
/* This code may be freely used and distributed in any project.  */
/* However, please do not remove this credit if you publish this */
/* code in paper or electronic form, such as on a web site.      */
/*****************************************************************/

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RefreshClock extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
  private static final long serialVersionUID = 1L;
  public void doGet(HttpServletRequest request, HttpServletResponse response)
                      throws ServletException, IOException {
    performTask(request, response);
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response)
                       throws ServletException, IOException {
    performTask(request, response);
  }

  private void performTask(HttpServletRequest request, HttpServletResponse response)
                          throws ServletException, IOException {
    response.setContentType("text/html");
    response.setHeader("Refresh", "15");
    PrintWriter out = response.getWriter();
    out.println("<html><head>");
    out.println("<title>Telling the Time</title></head>");
    out.println("<body>");
    out.println("Refresh Clock servlet says \"Hello\" at " + new Date());
    out.println("</body></html>");
  }
}