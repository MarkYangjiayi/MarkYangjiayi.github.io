package chain.web;           import chain.model.*;
import java.io.*;            import javax.servlet.*;
import javax.servlet.http.*; import java.util.*;

public class OperandsServlet extends HttpServlet {
  public void doPost(HttpServletRequest request,
                     HttpServletResponse response) throws ServletException, IOException {
    response.setContentType("text/html");
    DataBean db;

    // Get the current session object, create one if necessary.
    HttpSession session = request.getSession(true);
    if (session.isNew()) { // So first time.
      db = new DataBean();
      int op1 = Integer.parseInt(request.getParameter("op1"));
      int op2 = Integer.parseInt(request.getParameter("op2"));
      db.setOp1(op1);
      db.setOp2(op2);
      session.setAttribute("sum", db);
    
      try {
        PrintWriter out = response.getWriter();
        out.println("<HTML><HEAD><TITLE>Asking for Operator</TITLE></HEAD>");
        out.println("<BODY><H1>Asking for Operator</H1>");
        out.println("<form method='POST' action='http://localhost:9999/ServletDemos/DoSums'>");
        out.println("Input Operator");
        out.println("<input type='text' name='op' value=''> <br><br> ");
        out.println("<input type='submit' value='input operator'>");
        out.println("</form>");
        out.println("</BODY></HTML>");
        out.close();
      } 
      catch (java.io.IOException e) {
        System.err.println(" Print exception" +e);
      }
    } // end if
    else { // There is a session variable for this user.
      db = (DataBean)session.getAttribute("sum");
      String s = request.getParameter("op");
      db.setOperator(s);
      try { double x = db.calculate(); db.setAnswer(x); }
      catch(Exception e) { System.out.println(e); }
      session.setAttribute("sum", db);
      try {
        request.getRequestDispatcher("Display.jsp").forward(request, response);
      }
      catch (javax.servlet.ServletException e) {
        System.err.println(" Servlet exception" + e);
      }
      catch (java.io.IOException e) { 
        System.err.println(" Print exception" + e);
      }
      // getServletContext().getRequestDispatcher("/output.jsp").forward(request, response);
    }
  }
}

