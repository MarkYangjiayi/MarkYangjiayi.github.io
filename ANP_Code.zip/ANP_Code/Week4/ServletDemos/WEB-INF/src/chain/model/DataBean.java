package chain.model;
import java.io.*;

public class DataBean implements Serializable {
  private int op1;
  private int op2;
  private String operator;
  private double answer;

  public int getOp1() { return op1; }
  public int getOp2() { return op2; }
  public String getOperator() { return operator; }
  public double getAnswer() { return answer; }
  public void setOp1(int i) { op1 = i; }
  public void setOp2(int i) { op2 = i; }
  public void setOperator(String s) { operator = s; }
  public void setAnswer(double i) { answer = i; }
  public double calculate() throws Exception {
    if (operator.equals("add")) return op1+op2;
    if (operator.equals("multiply")) return op1*op2;
    if (operator.equals("subtract")) return op1-op2;
    if (operator.equals("divide"))
      return ((double) op1)/((double)op2);
    throw new Exception();
  }
} // End of DataBean class.
