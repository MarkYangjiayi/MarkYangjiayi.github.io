import chain.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

import java.util.*;

public class HoroscopeServlet extends HttpServlet {

  public void doGet(HttpServletRequest request,
                    HttpServletResponse response) throws IOException,
                                                         ServletException {

    RequestDispatcher view = request.getRequestDispatcher("display.jsp");

    HttpSession session = request.getSession();
    session.setMaxInactiveInterval(200);
    //PrintWriter out = response.getWriter();
    PersonalDetailsBean db;
    if (session.isNew()){
      db = new PersonalDetailsBean();
      db.setName(request.getParameter("name"));
      db.setSex(Boolean.getBoolean(request.getParameter("sex")));
      db.setZodiac(Integer.parseInt(request.getParameter("zodiac")));
      session.setAttribute("bean", db);
    }
    else{
      db = (PersonalDetailsBean)session.getAttribute("bean");
      db.setName(request.getParameter("name"));
      db.setSex(Boolean.getBoolean(request.getParameter("sex")));
      db.setZodiac(Integer.parseInt(request.getParameter("zodiac")));
      session.setAttribute("bean", db);
    }
    view.forward(request, response);
  }
}

//javac -cp /Library/Tomcat/lib/servlet-api.jar:/Library/Tomcat/webapps/Lab4/WEB-INF/classes /Library/Tomcat/webapps/Lab4/WEB-INF/classes/HoroscopeServlet.java
