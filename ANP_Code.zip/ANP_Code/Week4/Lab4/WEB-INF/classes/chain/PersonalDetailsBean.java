package chain;
import java.io.*;
public class PersonalDetailsBean implements Serializable {
  private String name;
  private int zodiac;
  private boolean sex;

  public PersonalDetailsBean(){}
  public String getName() {return name;}
  public int getZodiac() {return zodiac;}
  public boolean getSex() {return sex;}
  public void setName(String usrName){ name = usrName;}
  public void setZodiac(int usrZodiac){ zodiac = usrZodiac;}
  public void setSex(boolean usrSex){ sex = usrSex;}
}
