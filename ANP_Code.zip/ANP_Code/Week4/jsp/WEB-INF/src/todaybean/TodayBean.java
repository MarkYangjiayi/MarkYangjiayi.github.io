package todaybean;

import java.util.*;
import java.io.Serializable;

public class TodayBean implements Serializable { 
  private Date d;

  public TodayBean() { d = new Date(); }
  public String getDate() { return d.toString(); }
}