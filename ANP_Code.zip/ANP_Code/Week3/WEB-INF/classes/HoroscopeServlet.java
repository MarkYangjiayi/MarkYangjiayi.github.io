import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

import java.util.*;

public class HoroscopeServlet extends HttpServlet {

  public void doGet(HttpServletRequest request,
                    HttpServletResponse response) throws IOException,
                                                         ServletException {
    String usrName = request.getParameter("usrname");
    String usrSex = request.getParameter("usrsex");
    int usrZodiac = Integer.parseInt(request.getParameter("usrzodiac"));
    // String usrName = null;//what is a empty string?
    // String usrSex = "male";
    // int usrZodiac = 5;


    response.setContentType("text/html");
    PrintWriter out = response.getWriter();

    out.println("<html>");
    out.println("<head>");
    out.println("<title>First Servlet</title>");



    out.println("</head>");
    out.println("<body>");
    out.println("<h3>Welcome to HoroscopeServlet</h3>");

    out.println("<script>");
    // out.println("var sign =" + usrZodiac);
    // out.println("var gender =" + usrName);
    // out.println("function displayHoroscope(gender, sign){");
    // out.println("if(gender ==\"male\"){document.write(\"You are Male\")}");
    // out.println("if(gender ==\"female\"){alert(\"you are female\")}");
    // out.println("}");
    // out.println("displayHoroscope(gender,sign);");
    out.println("var gender = \"" + usrSex + "\";");
    out.println("var sign = " + usrZodiac + ";");
    // out.println("var gender = \"male\";");
    out.println("function test(){");
    out.println("if(gender ==\"male\" && sign <= 6){");
    out.println("document.write(\"You will have a long life.\");");
    out.println("}");
    out.println("if(gender ==\"male\" && sign >= 6){");
    out.println("document.write(\"You will have a rich life.\");");
    out.println("}");
    out.println("if(gender ==\"female\" && sign <= 6){");
    out.println("document.write(\"You will find a tall handsome stranger.\");");
    out.println("}");
    out.println("if(gender ==\"female\" && sign >= 6){");
    out.println("document.write(\"You will have six children.\");");
    out.println("}");
    out.println("}");
    out.println("test();");
    out.println("</script>");


    out.println("</body>");
    out.println("</html>");

    //ORIGINAL PROGRAMME
    // if(usrName == null){
    //   out.println("Please identify yourself , so that your horoscope can be given! ");
    //   out.println("</body>");
    //   out.println("<html>");
    //   return;
    // }
    // out.println("Hello" + usrName + "<br>");
    // switch(usrSex){
    //   case "male" :
    //     if(usrZodiac <=6 ){
    //       out.println("You will have a long life.");
    //     }
    //     else{
    //       out.println("You will have a rich life.");
    //     }
    //     break;
    //   case "female":
    //     if(usrZodiac <= 6){
    //       out.println("You will find a tall handsome stranger.");
    //     }
    //     else{
    //       out.println("You will have six children.");
    //     }
    //     break;
    //   default:
    //     out.println("You're not human.");
    // }
    // out.println("</body>");
    // out.println("<html>");
  }
}
