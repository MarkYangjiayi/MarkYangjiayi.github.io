public class Test implements Runnable{
  public void run(){
    try {
      System.out.println("in run() - about to enter work");
      work();
      System.out.println("in run() - back from work");
    }
    catch(InterruptedException x) {
      System.out.println("in run() - interrupted!");
    }
    System.out.println("Leaving thread");
  }

  public void work() throws InterruptedException{
    while (true){
      if (Thread.currentThread().isInterrupted()){//If flag is true
        System.out.println("C is " + Thread.currentThread().isInterrupted());
        Thread.sleep(400000);
        System.out.println("D is " + Thread.currentThread().isInterrupted());
      }
    }
  }

  public static void main(String[] args){
    Test myTest = new Test();
    Thread t = new Thread(myTest);
    t.start();
    try{
      Thread.sleep(2000);
    }
    catch(InterruptedException e){}
    t.interrupt();
    // try{
    //   Thread.sleep(2000);
    // }
    // catch(InterruptedException e){}

    System.out.println("Leaving main");
  }
}
// Result:
// in run() - about to enter work
// Leaving main
// C is true
// in run() - interrupted!
// Leaving thread
