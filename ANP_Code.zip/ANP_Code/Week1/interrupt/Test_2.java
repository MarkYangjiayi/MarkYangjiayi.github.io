public class Test_2 implements Runnable{
  public void run(){
    while (!Thread.currentThread().interrupted()){
      System.out.println("Entering thread");
      try {
        System.out.println("Running in thread.");
        Thread.sleep(500);
      }
      catch(InterruptedException x) {
        System.out.println("in run() - interrupted!");
      }
      System.out.println("Leaving thread");
    }
  }

  public static void main(String[] args){
    Test_2 myTest = new Test_2();
    Thread t = new Thread(myTest);
    //t.setDaemon(true); //With this set, the loop will not go on forever.
    t.start();
    try{
      Thread.sleep(200);
    }
    catch(InterruptedException e){}
    t.interrupt();
  }
}
// Result:
// Entering thread
// Running in thread.
// in run() - interrupted!
// Leaving thread

// Entering thread
// Running in thread.
// Leaving thread
//...
