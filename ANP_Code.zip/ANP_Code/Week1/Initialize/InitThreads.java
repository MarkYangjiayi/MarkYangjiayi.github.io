public class InitThreads extends Thread{
  public void run(){
    System.out.println("Hi from Thread!");
  }
  public static void main(String[] args){
    //Runnable
    Run myRun = new Run();
    Thread myThread_1 = new Thread(myRun);
    //Thread
    InitThreads myThread_2 = new InitThreads();

    myThread_1.start();
    myThread_2.start();
  }
}

// Runnable : an interface that requires you to implement a run() method.
// Thread : extends the Thread object and override the run() method.
//
// With extending Thread, you cannot extend another class, because java only
// allows a class to extend one superclass.
// Using the runnable interface allows another class to be extended if necessary
//
// Thread class has two constructors, one with parameter and another without.

//Definition of threads
//Difference between Process and Threads
