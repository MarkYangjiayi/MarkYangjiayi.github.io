public class Run implements Runnable{
  public void run(){
    System.out.println("Hi from runnable!");
  }
}
