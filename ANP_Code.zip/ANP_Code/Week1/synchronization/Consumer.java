//package synchronization;

public class Consumer implements Runnable {
	private Buffer buffer;

	public Consumer(Buffer b) {
		buffer = b;
	}

	public void run() {
		for (int i = 0; i<250 ; i++) {
//			System.out.println("hi2");
			System.out.println(buffer.get());
		}
		System.out.println("ended");
	}

	public static void main(String[] args) {
		Buffer myBuffer = new Buffer(4);
		Consumer myConsumer = new Consumer(myBuffer);
		Producer myProducer = new Producer(myBuffer);
		Thread myCon = new Thread(myConsumer);
		Thread myPro = new Thread(myProducer);
		myPro.start();
		myCon.start();
	}
}
