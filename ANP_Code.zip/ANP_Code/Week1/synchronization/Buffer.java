//package synchronization;

public class Buffer {
	private int[] buf;
	private int last;

	public Buffer(int sz) {
		buf = new int[sz];
		last = 0;
	}

	public boolean isFull() {
		return(last == buf.length);
	}

	public boolean isEmpty() {
		return(last == 0);
	}

	public synchronized void put(int c) {
		while(isFull()) {
			try {
				notify();
				wait();
			}
			catch(InterruptedException e) {
			}
		}
		buf[last++] = c;

	}

	public synchronized int get() {
		while(isEmpty()) {
			try {
				notify();
				wait();
			}
			catch(InterruptedException e) {

			}
		}
		int c = buf[0];
		System.arraycopy(buf, 1, buf, 0, --last);

		return c;
	}
}
