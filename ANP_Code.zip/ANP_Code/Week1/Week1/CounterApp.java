package Week1;

public class CounterApp {
	public static void main(String[] args) {
		Counter myCounter = new Counter();
		SleepyCounter myCounter1 = new SleepyCounter();
		Thread myThread = new Thread(myCounter1);
		myCounter.start();
		myThread.start();
	}
}
