package Week1;

public class Counter extends Thread {
	public void run() {
		int i;
		for (i=10;i<=500;i++) {
			System.out.println("Counting " + i);
			
		}
	}
	
	public static void main(String[] args) {
		Counter myCounter = new Counter();
		myCounter.start();
	}
}
