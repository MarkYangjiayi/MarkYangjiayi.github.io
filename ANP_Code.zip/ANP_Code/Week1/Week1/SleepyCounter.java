package Week1;

public class SleepyCounter implements Runnable {
	public void run() {
		int i;
		for (i=10;i<=500;i++) {
			System.out.println("Counting " + i);
//			try {
//				Thread.sleep(5);
//			}
//			catch(InterruptedException e){
//				e.printStackTrace();
//			}
		}
	}
	
	public static void main(String[] args) {
		SleepyCounter myCounter = new SleepyCounter();
		Thread myThread = new Thread(myCounter);
		myThread.start();
	}
}
